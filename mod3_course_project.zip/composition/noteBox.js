import React from 'react';
import './Note.css';

function Note(props) {
    return (

            <div className='noteBox'>
               this work?
            </div>
    );
}

export default Note;