import React, { Component } from 'react';
import Note from './composition/Note';
import TextBox from './composition/TextBox'
import './App.css';

class App extends Component {

  render () {
    
  return (

    <main className="App">

      <div id="inputContainer">
      <textBox>  <label for="textBox">Enter Note</label>
      <input type="text" id="textBox" name="textBox" size="40"></input></textBox>
      </div>

      <div id='noteContainer'>

    <Note></Note>

    <Note></Note>

    <Note></Note>

    <Note></Note>

      </div>
    </main>

  );
}
}

export default App;
