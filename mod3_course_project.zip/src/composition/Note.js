import React from 'react';
import './Note.css';

function Note(props) {
    const checkbox = <input type='checkbox'></input>
    return (
        <div className='noteBox'>
            <ul >
                <li>{checkbox}list item 1</li>
                <li>{checkbox}list item 2</li>
                <li>{checkbox}list item 3</li>
            </ul>
        </div>
    );
};

export default Note;