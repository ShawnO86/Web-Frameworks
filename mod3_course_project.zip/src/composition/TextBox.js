import React from 'react';
import './TextBox.css';


function TextBox(props) {

    return (
        <div id="inputContainer">

        </div>
    );
};

export default TextBox;