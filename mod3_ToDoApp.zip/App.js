import React, { useState } from 'react';
import './App.css';

function App(){
const [todos, setTodos] = useState([])
const [todo, setTodo] = useState("")

function handleSubmit(e) {
  e.preventDefault()

  const newTodo = {
    id: new Date().getTime(),
    text: todo,
    completed: false
  }

  setTodos([...todos].concat(newTodo))
  setTodo("")
}

function deleteTodo(id) {
  const updatedTodos = [...todos].filter((item) => item.id !== id)

  setTodos(updatedTodos)
}

function toggle(id) {
  const updatedTodos = [...todos].map((item) => {
    if(item.id == id) {
      item.completed = !item.completed
    }
    return item
  })
  setTodos(updatedTodos)
}

  return (
    <div className='App'>
<h1>ToDo List in React.js</h1>
<form onSubmit={handleSubmit}>
  <input type='text' className='textBox' onChange={(e) => setTodo(e.target.value)} value={todo}></input>
  <button type='submit' className='addBtn'>Add</button>
</form>

<ul>
{todos.map((item) => 
  <li key={item.id}>
    {item.text}
  <button className='delBtn' onClick={() => deleteTodo(item.id)}>X</button>
  <input type="checkbox" className='checkBox' onChange={() => toggle(item.id)} checked={item.completed}/>
</li>
)}
</ul>
    </div>
  )
}
export default App;
